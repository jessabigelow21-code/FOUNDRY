Crazy Joe Team Builder

GitHub Pages setup:
1. Create a new public repository named: crazy-joe-team-builder
2. Upload index.html from this folder.
3. Open the repository's Settings.
4. Choose Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Choose branch: main and folder: /root.
7. Save.

Your link will usually be:
https://YOUR-GITHUB-USERNAME.github.io/crazy-joe-team-builder/

The roster saves locally in the browser. Use Export Backup regularly so you can restore it on another device.
